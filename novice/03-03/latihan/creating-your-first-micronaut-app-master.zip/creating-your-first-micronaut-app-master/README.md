# Creating your first Micronaut app #

This guide is available at http://guides.micronaut.io/creating-your-first-micronaut-app/guide/index.html
