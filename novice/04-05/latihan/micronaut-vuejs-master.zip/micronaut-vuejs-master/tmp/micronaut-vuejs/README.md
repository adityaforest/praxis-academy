# micronaut-vuejs

A template project for rapid development of a VueJS project with Micronaut backend