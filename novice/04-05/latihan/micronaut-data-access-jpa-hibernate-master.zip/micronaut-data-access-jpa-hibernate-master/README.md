[Guide](http://guides.micronaut.io/micronaut-data-access-jpa-hibernate/guide/index.html)
