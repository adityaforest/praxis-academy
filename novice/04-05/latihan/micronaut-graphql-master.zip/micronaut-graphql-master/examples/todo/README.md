# Micronaut GraphQL To-Do example

Start the application:

    ./gradlew clean :graphql-example-todo:run

Open the embedded [Graph<i>i</i>QL](http://localhost:8080/graphiql) IDE to interact with the GraphQL To-Do API.
