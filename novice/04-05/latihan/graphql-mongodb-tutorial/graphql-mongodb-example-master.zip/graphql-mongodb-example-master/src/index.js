import 'babel-core/register'
import 'babel-polyfill'
import {start} from './start'
start()
